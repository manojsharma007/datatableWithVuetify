<template>
  <div class="HomeWorld">HomeWorld Componect</div>
</template>

<script>
export default {
  name: 'HomeWorld',
 
}
</script>